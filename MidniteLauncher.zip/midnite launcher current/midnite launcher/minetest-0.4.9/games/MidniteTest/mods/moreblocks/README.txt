Calinou's Minetest Mods
=====================

Calinou's Mods for Minetest [http://minetest.net], a free and opensource Minecraft-like game.

This Git repository is mostly made for servers; it allows easy updating.

To install, just clone this repository somewhere, then copy the "calinou_mods" folder in the "mods/minetest" folder of Minetest's installation folder.



Misc stuff
=====================

All these mods' source codes, except More Ores are under the zlib/libpng license. More Ores is under the GNU GPLv3; the mods' textures are under the CC BY-SA 3.0 Unported.

Mods' forum threads:
More Blocks: http://minetest.net/forum/viewtopic.php?id=509
More Ores: http://minetest.net/forum/viewtopic.php?id=549
Map Tools: http://minetest.net/forum/viewtopic.php?id=1882
Doors+: http://minetest.net/forum/viewtopic.php?id=2059
Stairs+: http://minetest.net/forum/viewtopic.php?id=2092
