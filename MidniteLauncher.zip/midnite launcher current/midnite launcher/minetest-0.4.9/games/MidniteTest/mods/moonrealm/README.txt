moonrealm 0.5.3 by paramat
For latest stable Minetest and back to 0.4.8
Depends default
Licenses: code WTFPL, textures CC BY-SA

Crafting
--------
default water source
I
I = waterice

luxnode
CCC
CCC
CCC
C = luxcrystal

airgen
SIS
ILI
SIS
S = steel ingot
I = waterice
L = luxnode

hlsource
LLL
LIL
LLL
L = moonrealm:leaves
I = waterice

airlock
S-S
SLS
S-S
S = steel ingot
L = luxnode

moonstonebrick x 4
MM
MM
M = moonstone

moonstonestair x 4
M
MM
M = moonstone

moonstoneslab x 4
MM
M = moonstone

default furnace
MMM
M-M
MMM
M = moonstone