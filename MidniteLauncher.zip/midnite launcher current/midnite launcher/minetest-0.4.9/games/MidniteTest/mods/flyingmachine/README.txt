Minetest 0.4,6 mod: Simple helicopter
=======================
by Pavel_S

License of source code:
-----------------------
WTFPL

License of media (textures and sounds):
---------------------------------------
WTFPL

Authors of media files:
-----------------------
textures: Pavel_S
model: Pavel_S
