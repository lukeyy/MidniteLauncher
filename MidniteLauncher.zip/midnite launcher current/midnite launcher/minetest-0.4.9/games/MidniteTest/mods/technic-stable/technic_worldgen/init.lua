-- Minetest 0.4.6 : technic_worldgen

modpath=minetest.get_modpath("technic_worldgen")

dofile(modpath.."/nodes.lua")
dofile(modpath.."/oregen.lua")
dofile(modpath.."/crafts.lua")
