local path = technic.modpath.."/machines/other"

-- mesecons and tubes related
dofile(path.."/injector.lua")
dofile(path.."/node_breaker.lua")
dofile(path.."/deployer.lua")
dofile(path.."/constructor.lua")
dofile(path.."/frames.lua")
