local path = technic.modpath.."/machines/hv"

dofile(path.."/forcefield.lua")
dofile(path.."/wires.lua")
dofile(path.."/battery_box.lua")
dofile(path.."/solar_array.lua")
dofile(path.."/nuclear_reactor.lua")

