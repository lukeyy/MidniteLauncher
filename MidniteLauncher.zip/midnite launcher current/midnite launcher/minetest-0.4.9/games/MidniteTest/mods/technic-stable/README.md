technic 0.4.7

Technic mod for Minetest 0.4.7

Credits for contributing to the project:
Nekogloop
ShadowNinja
VanessaE
Nore/Novatux
kpoppel
And many others for ideas/inspiring 

Licences:
TO-DO
