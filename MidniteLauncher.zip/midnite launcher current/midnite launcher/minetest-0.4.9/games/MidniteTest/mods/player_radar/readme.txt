player_radar 0.1
Copyright (c) 2013 pandaro <padarogames@gmail.com>

sourcecode:https://github.com/pandaro/player_radar
code:GPLv3
pictures:WTFPL
depends:default


THIS MOD ADD:
-RADAR:A block that shows the objects within a radius(the center of radious is the position of the RADAR BLOCK).
-PORTABLE RADAR:A  item that show objects within a radius(the center of radious is the position of the PLAYER).
-PORTABLE RADAR RECEIVER:A item that show objects within a radious(the center of radious is the position of the RADAR BLOCK).
-RADAR HUD:A item that show objects inside a radious(the center of radious is the position of the PLAYER) through a hud display.
CRAFTING:


O=empty slot
S=steelblock
M=Mese Crystal
R=Radar Block
RADAR BLOCK:
OOO
OMO
SSS

PORTABLE_RADAR:
OMO
OMO
ORO

PORTABLE RADAR RECEIVER:
OMO
ORO
OMO

RADAR HUD:
ORO
OMO
OMO

How to:
RADAR:
-Place a radar on ground, right click on it for open radar screen.The radar beam is determined by its y coordinate(y/2).
PORTABLE RADAR:
-use it only.
PPORTABLE RADAR RECEIVER:
-To connect a receiver to a radar, you have to click with the PORTABLE RECEIVER with the left mouse button over a RADAR BLOCK, now use it to simply press the left mouse button.
RADAR HUD:
-use it simply switch on and off

CHANGELOG:
player_radar_v0.1:
-Place a radar on ground, right click on it for open radar screen.The radar beam is determined by its y coordinate(y/2)

player_radar_v0.2:
-ADD:
-PORTABLE RADAR;
-PORTABLE RADAR RECEIVER;
-RADAR HUD.
			
			  

TO DO:
-A map background.
      