-- spacesuit 0.1.0 by paramat.
-- License WTFPL, see license.txt.

-- Variables.

local SPADAM = 7 -- Spacedamage in hit points, 0 = disable the damage on-generated function, 20 = instant death.
local ATMOS = 1024 -- 1024 -- Atmosphere depth,
			-- players above this without a spacesuit in their inventory get spacedamage
			-- every time a new chunk generates (every few seconds).

-- Stuff.

spacesuit = {}

-- Items.

minetest.register_craftitem("spacesuit:spacesuit", {
	description = "Spacesuit",
	inventory_image = "spacesuit_spacesuit.png",
	groups = {not_in_creative_inventory=1},
})

minetest.register_craftitem("spacesuit:helmet", {
	description = "Mesetinted Helmet",
	inventory_image = "spacesuit_helmet.png",
	groups = {not_in_creative_inventory=1},
})

minetest.register_craftitem("spacesuit:lifesupport", {
	description = "Life Support",
	inventory_image = "spacesuit_lifesupport.png",
	groups = {not_in_creative_inventory=1},
})

-- Crafting.

minetest.register_craft({
	output = "spacesuit:helmet",
	recipe = {
		{"default:mese"},
		{"default:glass"},
		{"default:steel_ingot"},
	}
})

minetest.register_craft({
	output = "spacesuit:lifesupport",
	recipe = {
		{"default:steel_ingot","default:mese" , "default:steel_ingot"},
		{"default:steel_ingot", "", "default:steel_ingot"},
		{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
	}
})

minetest.register_craft({
	output = "spacesuit:spacesuit",
	recipe = {
		{"wool:white", "spacesuit:helmet", "wool:white"},
		{"", "spacesuit:lifesupport", ""},
		{"wool:white", "", "wool:white"},
	}
})

-- On generated function.

if SPADAM ~= 0 then
	minetest.register_on_generated(function(minp, maxp, seed)
		for _,player in ipairs(minetest.get_connected_players()) do
			local pos = player:getpos()
			if player:get_inventory():contains_item("main", "spacesuit:spacesuit") == false and pos.y > ATMOS then
				player:set_hp(player:get_hp() - SPADAM)
			end
		end
	end)
end
