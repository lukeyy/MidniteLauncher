Bees
----
Wild bees that spawn near flowers and in trees that can be harvested and domesticated

version
-------
0.5

contributors
------------
bas080
VanessaE
Neuromancer
Minetest community

forum
-----
https://forum.minetest.net/viewtopic.php?pid=102905

license
-------
WTFPL
